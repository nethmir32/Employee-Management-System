import React from 'react'
import '../css/Footer.css'

const FooterComponent = () => {
  return (
    <div>
        <br />
        <br />
        <footer className='footer'>
            <span>All rights reserved 2024 by javaguides</span>
        </footer>
    </div>
  )
}

export default FooterComponent