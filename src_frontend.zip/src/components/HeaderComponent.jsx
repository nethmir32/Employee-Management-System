import React from 'react'

const HeaderComponent = () => {
  return (
    <div>
        <header>
            <nav className="navbar fixed-top navbar-dark bg-dark">
            <a class="navbar-brand" href="#">Employee Management System</a>
            </nav>
        </header>
        <br />
        <br />
        <br />
    </div>
  )
}

export default HeaderComponent